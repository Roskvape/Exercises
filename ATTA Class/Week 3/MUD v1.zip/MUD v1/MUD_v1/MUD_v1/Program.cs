﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MUD_v1
{
    class Program
    {


        static void Main(string[] args)
        {
            ConsoleKey ckInput = ConsoleKey.E;

            Map.PrintMap();
            Console.ReadKey();
            
            //Spawn player
            Map.CurrentMap[Player.sPlayerRow, Player.sPlayerCol] = Player.sPlayerToken;
            Map.RefreshMap();

            while (ckInput != ConsoleKey.Escape)
            {
                ckInput = Console.ReadKey().Key;
                if (ConsoleKey.UpArrow == ckInput || ConsoleKey.DownArrow == ckInput || ConsoleKey.LeftArrow == ckInput || ConsoleKey.RightArrow == ckInput)
                {
                    Player.MovePlayer(ckInput);
                }
            }
            if (ckInput == ConsoleKey.Escape)
            {
                Environment.Exit(0);
            }

            Console.ReadKey();
        }
    }
}
