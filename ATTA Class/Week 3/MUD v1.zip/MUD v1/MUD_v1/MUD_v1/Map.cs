﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MUD_v1
{
    class Map
    {
        static public string[,] CurrentMap = new string[,]
        {
            { "-", "-", "-", "-", "-" },
            { "-", "-", "-", "-", "-" },
            { "-", "-", "-", "-", "-" },
            { "-", "-", "-", "-", "-" },
            { "-", "-", "-", "-", "-" }
        };

        static public void RefreshMap()
        {
            Console.Clear();
            PrintMap();
        }

        static public void PrintMap()
        {
            for (int row = 0; row < CurrentMap.GetLength(0); row++)
            {
                for (int col = 0; col < CurrentMap.GetLength(1); col++)
                {
                    Console.Write(CurrentMap[row, col] + " ");
                }
                Console.Write("\n");
            }
        }
    }
}
