﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MUD_v1
{
    class Player
    {
        static public string sPlayerToken = "X";
        static public int sPlayerRow = 2;
        static public int sPlayerCol = 2;

        static public void MovePlayer(ConsoleKey ckDirection)
        {
            if (ConsoleKey.UpArrow == ckDirection)
            {
                if (Player.sPlayerRow > 0)
                {
                Map.CurrentMap[Player.sPlayerRow, Player.sPlayerCol] = "-";
                Map.CurrentMap[Player.sPlayerRow -= 1, Player.sPlayerCol] = Player.sPlayerToken;
                }
                else { }
            }
            else if (ConsoleKey.DownArrow == ckDirection)
            {
                if (Player.sPlayerRow < Map.CurrentMap.GetLength(0)-1)
                {
                    Map.CurrentMap[Player.sPlayerRow, Player.sPlayerCol] = "-";
                    Map.CurrentMap[Player.sPlayerRow += 1, Player.sPlayerCol] = Player.sPlayerToken;
                }
                else { }
            }
            else if (ConsoleKey.LeftArrow == ckDirection)
            {
                if (Player.sPlayerCol > 0)
                {
                    Map.CurrentMap[Player.sPlayerRow, Player.sPlayerCol] = "-";
                    Map.CurrentMap[Player.sPlayerRow, Player.sPlayerCol -= 1] = Player.sPlayerToken;
                }
                else { }
            }
            else if (ConsoleKey.RightArrow == ckDirection)
            {
                if (Player.sPlayerCol < Map.CurrentMap.GetLength(1) - 1)
                {
                    Map.CurrentMap[Player.sPlayerRow, Player.sPlayerCol] = "-";
                    Map.CurrentMap[Player.sPlayerRow, Player.sPlayerCol += 1] = Player.sPlayerToken;
                }
                else { }
            }
            Map.RefreshMap();
        }
    }
}
