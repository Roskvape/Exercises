﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session_3_Exercises
{
    class Employee
    {
        // fields

        public string name;
        public string title;
        private uint id;
        private static uint maximumId = 1000;

        // properties

        public uint Id
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
                if (id > maximumId)
                    id = maximumId;
            }
        }

        // constructors

        public Employee(string _name, string _title, uint _id)
        {
            name = _name;
            title = _title;
            Id = _id;       // NOTE: Assigned to property Id, not to field id!
        }

        public Employee()
        {
            name = "Jane Doe";
            title = "Space Marine";
            Id = 324;
        }

        // other methods

        public void Report()
        {
            Console.WriteLine("Employee: {0}, {1}. ID: {2}", name, title, id);
        }


    }
}
