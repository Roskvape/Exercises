﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session_3_Exercises
{
    class Program
    {
        static void CompareEmployeeIds(Employee e1, Employee e2)
        {
            if (e1.Id > e2.Id)
            {
                Console.WriteLine(e1.name);
            }
            else if (e1.Id < e2.Id)
            {
                Console.WriteLine(e2.name);
            }
            else
            {
                Console.WriteLine("Warning: Id's are identical!");
            }
        }

        static void Main(string[] args)
        {
            Employee alice = new Employee("Alice", "Pet Sitter", 309);
            Employee bob = new Employee("Bob", "Basket Weaver", 2020);    // NOTE: Invalid ID! Our property should fix this.
            CompareEmployeeIds(alice, bob);
        }
    }
}
